def soma(a,b,c):
    print(a+b+c)
a = int(input(f'Digite primeiro número da soma:\n'))
b = int(input(f'Digite segundo número da soma:\n'))
c = int(input(f'Digite terceiro número da soma:\n'))

soma(a,b,c)   