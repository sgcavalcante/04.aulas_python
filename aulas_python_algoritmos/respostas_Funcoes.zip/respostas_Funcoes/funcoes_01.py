def imprimir(n):
    for i in range(1,n+1):
        
        print(i*str(i))

n = int(input(f'Digite número:\n'))
imprimir(n)     