def soma(a):
    if a>=0:
        print("P")
    else:
        print("N")
a = int(input(f'Digite um número:\n'))

soma(a)   