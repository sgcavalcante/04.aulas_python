numero1 = int(input("Digite um número:\n"))
numero2 = int(input("Digite outro número:\n"))
soma = numero1 + numero2
print(f"A soma dos números {numero1} e {numero2} é {soma}.")
