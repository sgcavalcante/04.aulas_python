numero1 = int(input("Digite a nota do 1º bimestre:\n"))
numero2 = int(input("Digite a nota do 2º bimestre:\n"))
numero3 = int(input("Digite a nota do 3º bimestre:\n"))
numero4 = int(input("Digite a nota do 4º bimestre:\n"))

soma = numero1 + numero2 + numero3 + numero4
media = soma/4

print(f"A as notas dos bimestres foram: \nNota 1:{numero1}\nNota 2:{numero2} \nNota 3:{numero3} \nNota 4:{numero4}. \nSua média anual é {media}")

