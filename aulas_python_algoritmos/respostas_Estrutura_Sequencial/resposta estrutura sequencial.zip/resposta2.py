numero1 = input("Digite um número:\n")
print(f'O número informado é {numero1}.')