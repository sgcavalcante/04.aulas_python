print("---Conversão de tempretarua---")
temperatura_f = float(input("Digite a temperatura em Fahrenheit:\n"))
#qtde_horas_trabalhadas = float(input("Digite a quantidade de horas trabalhados por mês:\n"))
temperatura_c = 5 * ((temperatura_f-32)/9)
print(f"A Temperatura em gruas Celsius é :{temperatura_c}")


