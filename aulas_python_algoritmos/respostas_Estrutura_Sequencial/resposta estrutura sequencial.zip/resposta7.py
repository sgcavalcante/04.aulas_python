print("---Cálculo da área de um quadrado---")
lado = float(input("Digite a extensão do lado do quadrado:\n"))
area = lado**2
print(f"A área do quadrado de lado {lado} é {area} metros quadrados.\nO dobro da área é: {2*area}")