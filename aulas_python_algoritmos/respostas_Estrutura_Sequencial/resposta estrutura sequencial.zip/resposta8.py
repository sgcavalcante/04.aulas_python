print("---Cálculo do salário mensal baseado em horas trabalhdas por dia---")
preco_hora = float(input("Digite o preco da hora trabalhada:\n"))
qtde_horas_trabalhadas = float(input("Digite a quantidade de horas trabalhados por mês:\n"))
salario_mensal = preco_hora * qtde_horas_trabalhadas
print(f"Seu salário é :{salario_mensal}")