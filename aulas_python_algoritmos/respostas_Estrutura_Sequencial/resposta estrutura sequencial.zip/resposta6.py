print("---Cálculo da área de um círculo---")
raio = float(input("Digite a extensão do raio:\n"))
area = 2 * 3.14 * raio**2
print(f"A área do circulo de raio {raio} é {area} metros quadrados.")