#https://wiki.python.org.br/EstruturaSequencial

print("Olá Mundo!")