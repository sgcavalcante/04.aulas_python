print("---Conversão de metro para centimetros---")
metros = float(input("Digite a extensão em metros:\n"))
centimetros = metros * 100
print(f"A extentsão informada de {metros} metros corresponde a {centimetros} centimetro(s).")