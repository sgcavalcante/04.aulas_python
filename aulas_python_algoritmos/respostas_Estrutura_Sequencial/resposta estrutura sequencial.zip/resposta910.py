print("---Conversão de tempretarua---")
temperatura_c = float(input("Digite a temperatura em Celcius:\n"))
#qtde_horas_trabalhadas = float(input("Digite a quantidade de horas trabalhados por mês:\n"))
#deduzir a formula
temperatura_f = (9 * ((temperatura_c/5)+32))
print(f"A Temperatura em gruas Fahenheit é :{temperatura_f}")