print(f'Programa Letra.')
l1=(input(f'Digite:\nF para Feminino\nM para Masculino\n'))
#l2=(input(f'Digite o 1º número:\n'))

if l1 == "F":
    print(f'F - Sexo Feminino')
elif l1 == "M":
    print(f'M - Sexo Masculino')
else:
    print(f'Sexo Inválido. Digite novamente')
