vogal = ['a','e','i','o','u']
l1=(input(f'Digite uma VOGAL:\n'))
if l1.lower() in vogal:
    print(f'{l1} é uma VOGAL')
else:
    print(f'{l1} NÂO é uma VOGAL')