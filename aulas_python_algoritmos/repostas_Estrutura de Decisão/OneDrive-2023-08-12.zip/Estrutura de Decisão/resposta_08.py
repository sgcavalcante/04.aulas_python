print(f'Programa indica produto com menor preço.')
n1=int(input(f'Digite o preço do 1º produto:\n'))
n2=int(input(f'Digite o preço do 2º produto:\n'))
n3=int(input(f'Digite o preço do 3º produto:\n'))
 

print(f"====Menor Número====\n")

if (n1 < n2) and (n1 < n3):
    print(f'Você deve comprar produto Número 1. Seu preço é R$ {n1}.00, o mais barato.')
    print(f'Números digitados: {n1} {n2} {n3}\n\n')
elif (n2 < n1) and (n2 < n3):
    print(f'Você deve comprar produto Número 2. Seu preço é R$ {n2}.00, o mais barato.')
    print(f'Números digitados: {n1} {n2} {n3}\n\n')

elif (n3 < n1) and (n3 < n2):
    print(f'Você deve comprar produto Número 3. Seu preço é R$ {n3}.00, o mais barato.')
    print(f'Números digitados: {n1} {n2} {n3}\n\n')
else:
    print(f'Inválido')