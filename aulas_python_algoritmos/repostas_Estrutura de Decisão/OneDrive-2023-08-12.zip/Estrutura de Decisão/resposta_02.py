print(f'Programa imprimi se numero digitado é positivo ou negativo.')
n1=int(input(f'Digite o 1º número:\n'))
#n2=int(input(f'Digite o 1º número:\n'))

if n1 > 0:
    print(f'Número {n1} é positivo.')
else:
    print(f'Número {n1} é negativo.')