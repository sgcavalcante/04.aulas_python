print(f'Programa imprimi maior valor.')
n1=int(input(f'Digite o 1º número:\n'))
n2=int(input(f'Digite o 2º número:\n'))

if n1 > n2:
    print(f'Número {n1} é maior que número {n2}')
else:
    print(f'Número {n2} é maior que número {n1}')