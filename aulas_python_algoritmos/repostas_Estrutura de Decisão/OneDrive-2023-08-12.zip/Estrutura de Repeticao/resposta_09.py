print(f'Programa Imprimir números impares de 1 a 50')

for i in range(0,50):
    if (i%2 != 0):
        print(i)