print(f'{10*"-"} Contagem até 20 {10*"-"}')
print(f'{10*"-"}{10*"-"}')
n1 = int(input(f"Digite 1º numero:\n"))
n2 = int(input(f"Digite 2º numero:\n"))

for i in range(n1+1,n2):
    print(i)