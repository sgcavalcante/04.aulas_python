print(f'{10*"-"} Contagem até 20 {10*"-"}')
print(f'{10*"-"}{10*"-"}')
for i in range(1,21):
    print(f'{i}')
print(f'{10*"-"}{10*"-"}')
for i in range(1,21):
    print(f'{i}',end =" ")    